const appointModel = require('../model/appointModel')


exports.slot_post = (req,res)=>{
    console.log('body slot',req.body);
    const {slotDate} = req.body
    appointModel.find({slotDate:slotDate}).then(selectedDateResult=>{
        // console.log(selectedDateResult);

        console.log(selectedDateResult);
        return res.status(200).json({ 
            status:'success',
            result :selectedDateResult,
            message: 'appointData Submitted',
          });

        }).catch(err=>{
            console.log('appointDate Error',err);
            return res.status(400).json({ 
                status:'Failed',
                message: 'appointDate Error',
              });
        })

        // checkIfAvailable = async (slot) => {
        //     let snapshot = await ref.orderByChild('slotDate').once('value');
        
        //     let available = true;
        
        //     snapshot.forEach((data) => {
        //       let dataval = data.val();
        //       for (let key in dataval) {
        //         let datapoint = dataval[key];
        //         if (slotTime === datapoint) {
        //           available = false;
        //         }
        //       }
        //     });
        //     return available;
        //   };
    
}